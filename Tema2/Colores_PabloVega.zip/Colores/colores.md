## Elección de colores

#### Azúl (#6faced)

He elegido este color porque transmite confianza y profesionalidad.

#### Blanco (#FFFFFF)

El blanco transmite simplicidad y claridad, hará que la web se vea más limpia y ayuda a que el resto de colores resalten.

#### Gris oscuro (#2d2d2d)

Simboliza elegancia y neutralidad, dará contraste a la web
